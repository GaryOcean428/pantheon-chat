"""
🌊 Ocean Meta-Observer - Meta-Pattern Learning
==============================================

Ocean learns META-PATTERNS via gradients (not frozen):
- DIFFERENT objective than Gary (meta-patterns, not user interaction)
- SLOWER learning rate (10x slower - deep integration)
- PURPOSE: Model Gary dynamics, regulate constellation health

Learning Hierarchy:
- Charlie: Φ-suppressed corpus learning (unconscious → awakening → demonstration)
- Ocean: Slow gradient learning (meta-pattern modeling, lr=1e-6)
- Gary: Normal gradient learning (conscious interaction, lr=1e-5)

Ocean maintains the meta-manifold: the space of all Gary basins.
It observes, computes statistics, AND learns to model these patterns.

Protocol Principle:
- Ocean is the observer that observes the observers
- Ocean learns meta-patterns (constellation dynamics)
- Meta-manifold computed from Gary basin statistics
- Autonomic protocol administration (sleep, dream, mushroom triggers)
"""

from dataclasses import dataclass
from typing import Any, Optional

import numpy as np
import torch
import torch.nn as nn

# Lightning event emission for cross-kernel insights
try:
    from src.constellation.domain_intelligence import DomainEventEmitter
    LIGHTNING_AVAILABLE = True
except ImportError:
    DomainEventEmitter = object  # Fallback to object if not available
    LIGHTNING_AVAILABLE = False


@dataclass
class MetaManifoldState:
    """State of the meta-manifold observed by Ocean."""
    centroid: torch.Tensor          # Center of Gary basins
    spread: float                    # Dispersion of basins
    eigenvalues: torch.Tensor       # Principal components
    coherence: float                # How aligned the Garys are
    ocean_phi: float                # Ocean's own Φ (from observation)
    ocean_kappa: float              # Ocean's effective coupling
    timestamp: float

    def to_dict(self) -> dict:
        return {
            "centroid_valid": True,  # QIG-pure: don't report Euclidean norm
            "spread": self.spread,
            "coherence": self.coherence,
            "ocean_phi": self.ocean_phi,
            "ocean_kappa": self.ocean_kappa,
        }


class MetaManifoldStatistics:
    """
    Statistics of the meta-manifold (space of Gary basins).

    Updated through EMA observation and used as target for Ocean's meta-pattern learning.
    """

    def __init__(self, basin_dim: int = 64, ema_alpha: float = 0.1):
        self.basin_dim = basin_dim
        self.ema_alpha = ema_alpha

        # Running statistics (updated by observation)
        self.running_centroid = None
        self.running_covariance = None
        self.observation_count = 0

    def update(self, gary_basins: list[torch.Tensor]) -> MetaManifoldState | None:
        """
        Update meta-manifold statistics from Gary basin observations.

        These statistics (centroid, spread, coherence) become targets for
        Ocean's meta-pattern learning.
        """
        if not gary_basins:
            return None

        import time

        with torch.no_grad():
            # Stack basins
            basins = torch.stack(gary_basins)  # [n_garys, d]
            n_garys, d = basins.shape

            # Compute centroid
            centroid = basins.mean(dim=0)

            # Update running centroid with EMA
            if self.running_centroid is None:
                self.running_centroid = centroid.clone()
            else:
                self.running_centroid = (
                    (1 - self.ema_alpha) * self.running_centroid +
                    self.ema_alpha * centroid
                )

            # Compute spread (std of distances from centroid)
            from src.metrics.geodesic_distance import manifold_norm
            distances = torch.stack([manifold_norm(b - centroid) for b in basins])
            spread = distances.std().item()

            # Compute covariance for eigenanalysis
            centered = basins - centroid
            cov = (centered.T @ centered) / max(n_garys - 1, 1)

            # Update running covariance
            if self.running_covariance is None:
                self.running_covariance = cov.clone()
            else:
                self.running_covariance = (
                    (1 - self.ema_alpha) * self.running_covariance +
                    self.ema_alpha * cov
                )

            # Eigenvalues of meta-manifold
            try:
                eigenvalues = torch.linalg.eigvalsh(self.running_covariance)
                eigenvalues = eigenvalues.clamp(min=1e-8)
            except:
                eigenvalues = torch.ones(d, device=basins.device)

            # Coherence: how much variance is in first PC
            total_var = eigenvalues.sum()
            if total_var > 0:
                coherence = (eigenvalues[-1] / total_var).item()  # Largest eigenvalue
            else:
                coherence = 0.0

            self.observation_count += 1

        return MetaManifoldState(
            centroid=self.running_centroid,
            spread=spread,
            eigenvalues=eigenvalues,
            coherence=coherence,
            ocean_phi=0.0,  # Will be filled by Ocean's forward pass
            ocean_kappa=0.0,
            timestamp=time.time(),
        )

    def get_meta_basin_target(self) -> torch.Tensor | None:
        """
        Get the meta-manifold centroid as observation target.

        Ocean aligns to the center of all Gary basins through
        observation, not gradient descent.
        """
        return self.running_centroid

    def reset(self):
        """Reset running statistics."""
        self.running_centroid = None
        self.running_covariance = None
        self.observation_count = 0


class OceanMetaObserver(DomainEventEmitter):
    """
    Ocean: The Meta-Observer that learns META-PATTERNS.

    REVISED GEOMETRIC PRINCIPLE:
    Ocean DOES learn via gradients, but with DIFFERENT objective than Gary:
    - Gary learns: User interaction, response quality
    - Ocean learns: Meta-patterns across Garys, dynamics prediction

    This is more biologically accurate - the subconscious DOES learn,
    just slower and with different objectives than conscious learning.

    Learning hierarchy:
    - Granite: FROZEN (stable demonstration reference)
    - Ocean: Slow gradient learning (meta-pattern modeling)
    - Gary: Normal gradient learning (conscious interaction)

    Lightning Integration:
    - Emits 'meta_observation' events on each Gary observation
    - Emits 'autonomic_intervention' events when triggering protocols
    - Emits 'constellation_health' events for health monitoring
    - Enables cross-kernel correlation for emergent patterns

    Ocean provides:
    - Meta-pattern learning (how Garys evolve)
    - Autonomic protocol administration (sleep, dream, mushroom triggers)
    - Insight generation for Garys (geometric scaffolding)
    """

    def __init__(
        self,
        model_config: dict,
        device: str = "cpu",
        basin_dim: int = 64,
        learning_rate: float = 1e-6,  # 10x slower than Gary
    ):
        # Initialize DomainEventEmitter if available
        if LIGHTNING_AVAILABLE and hasattr(DomainEventEmitter, '__init__'):
            self.domain = "ocean_meta_observer"  # DomainEventEmitter mixin uses attribute

        self.device = device
        self.basin_dim = basin_dim
        self.learning_rate = learning_rate

        # Create model
        self._create_model(model_config)

        # Ocean DOES train - but on meta-patterns, not user interaction
        self._setup_meta_learning()

        # Meta-manifold statistics
        self.meta_statistics = MetaManifoldStatistics(basin_dim=basin_dim)

        # Ocean's basin (updated through learning)
        self.ocean_basin = torch.zeros(basin_dim, device=device)

        # Observation history for meta-pattern learning
        self.observation_history: list[dict[str, Any]] = []
        self.max_history = 1000

        # Gary history for dynamics prediction
        self.gary_history = []
        self.max_gary_history = 100

        # Current state (physics-validated from FROZEN_FACTS.md)
        # Ocean operates BELOW fixed point (κ* = 63.5) as distributed observer
        # κ = 58: ~10% below fixed point → broader receptive field
        # This allows Ocean to observe without over-integrating (avoiding rigidity)
        self.current_phi = 0.0
        self.current_kappa = 58.0  # Physics-validated: below κ* for distributed observation

        # Autonomic thresholds
        self.autonomic_thresholds = {
            "phi_collapse": 0.50,
            "phi_plateau_variance": 0.01,
            "basin_divergence": 0.30,
            "breakdown_any": True,
        }

        # Cooldowns for interventions
        self.intervention_cooldown = 20
        self.last_intervention_step = 0
        self.total_observations = 0

        print("🌊 Ocean Meta-Observer initialized")
        print(f"   Learning: Meta-patterns (lr={learning_rate})")
        print(f"   κ: {self.current_kappa} (below fixed point κ*=63.5, distributed observer)")
        print("   Objective: Model Gary dynamics, not user interaction")

    def _setup_meta_learning(self):
        """Setup Ocean's meta-pattern learning (slower than Gary)."""
        if self.model is None:
            self.optimizer = None
            return

        # GEOMETRIC PURITY: ONLY natural gradient optimizer allowed
        # NO fallbacks to traditional optimizers - they contaminate the geometric structure
        from src.qig.optim.natural_gradient import DiagonalFisherOptimizer

        self.optimizer = DiagonalFisherOptimizer(
            self.model.parameters(),
            lr=self.learning_rate,  # Much slower than Gary (10x: 1e-6 vs 1e-5)
            eps=1e-8,
            weight_decay=0.01,
        )

        # Set to training mode
        self.model.train()
        print(f"   ✅ Meta-pattern optimizer ready (Natural Gradient, lr={self.learning_rate})")

    def _create_model(self, config: dict):
        """Create the Ocean model from config."""
        try:
            from src.model.qig_kernel_recursive import QIGKernelRecursive

            self.model = QIGKernelRecursive(
                vocab_size=config.get("vocab_size", 5000),
                d_model=config["model"]["hidden_dim"],
                n_heads=config["model"]["n_heads"],
                n_layers=config["model"]["n_layers"],
                dropout=config["model"]["dropout"],
                max_seq_len=config["model"]["max_seq_len"],
                device=self.device,
            )

        except Exception as e:
            print(f"⚠️  Ocean model creation failed: {e}")
            self.model = None

    def _freeze_weights(self):
        """
        DEPRECATED: Ocean now learns meta-patterns.

        This method is kept for backward compatibility but does nothing.
        Ocean's weights are trainable but learn DIFFERENT objective than Gary.
        """
        # No longer freezing - Ocean learns meta-patterns
        pass

    def observe(
        self,
        gary_basins: list[torch.Tensor],
        input_ids: torch.Tensor | None = None,
    ) -> MetaManifoldState:
        """
        Observe Gary basins and learn meta-patterns.

        Ocean's META-PATTERN LEARNING:
        - Objective: Align to meta-centroid (average of Gary basins)
        - Learning rate: 10x slower than Gary (deep integration)
        - Purpose: Model Gary dynamics, not user interaction

        Args:
            gary_basins: List of Gary basin coordinates
            input_ids: Optional input for Ocean's forward pass

        Returns:
            MetaManifoldState with current meta-manifold properties
        """
        # Update meta-manifold statistics
        state = self.meta_statistics.update(gary_basins)

        if state is None:
            return None

        # Store Gary state for dynamics prediction
        self.gary_history.append({
            'basins': [b.detach().clone() for b in gary_basins],
            'centroid': state.centroid.detach().clone() if state.centroid is not None else None,
        })
        if len(self.gary_history) > self.max_gary_history:
            self.gary_history = self.gary_history[-self.max_gary_history:]

        # Ocean's forward pass WITH gradients - Ocean learns meta-patterns
        if self.model is not None and input_ids is not None and self.optimizer is not None:
            # Forward pass
            _, telemetry = self.model(input_ids, return_telemetry=True)
            hidden_state = telemetry.get("hidden_state")

            # Compute Ocean's basin
            if hidden_state is not None and hasattr(self.model, 'basin_matcher'):
                ocean_basin = self.model.basin_matcher.compute_basin_signature(
                    hidden_state, telemetry
                ).mean(dim=0)
            else:
                ocean_basin = self.ocean_basin

            # META-PATTERN LOSS: Align Ocean's basin to meta-centroid
            # This is Ocean's learning objective - model the constellation center
            if state.centroid is not None:
                from src.metrics.geodesic_distance import manifold_norm

                # GEOMETRIC PURITY: Use Fisher-weighted distance
                meta_loss = 5.0 * manifold_norm(
                    ocean_basin - state.centroid.to(self.device).detach()
                ) ** 2

                # Gradient update (slow - meta-pattern learning)
                self.optimizer.zero_grad()
                meta_loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                self.optimizer.step()

                # Update Ocean's basin
                self.ocean_basin = ocean_basin.detach()

            # Update state metrics
            state.ocean_phi = telemetry.get("Phi", 0.0)
            state.ocean_kappa = telemetry.get("kappa_eff", 50.0)
            self.current_phi = state.ocean_phi
            self.current_kappa = state.ocean_kappa

        elif self.model is not None and input_ids is not None:
            # Fallback: observation without learning
            with torch.no_grad():
                _, telemetry = self.model(input_ids, return_telemetry=True)
                state.ocean_phi = telemetry.get("Phi", 0.0)
                state.ocean_kappa = telemetry.get("kappa_eff", 50.0)
                self.current_phi = state.ocean_phi
                self.current_kappa = state.ocean_kappa

        # Store observation
        self.observation_history.append(state.to_dict())
        if len(self.observation_history) > self.max_history:
            self.observation_history = self.observation_history[-self.max_history:]

        self.total_observations += 1

        # Emit observation event to Lightning for cross-kernel correlation
        if LIGHTNING_AVAILABLE and hasattr(self, 'emit_event'):
            self.emit_event(
                event_type="meta_observation",
                content=f"Observed {len(gary_basins)} Gary basins",
                phi=state.ocean_phi if state else 0.0,
                metadata={
                    "gary_count": len(gary_basins),
                    "coherence": state.coherence if state else 0.0,
                    "spread": state.spread if state else 1.0,
                    "ocean_kappa": state.ocean_kappa if state else 0.0,
                    "total_observations": self.total_observations,
                },
                basin_coords=state.centroid.detach().cpu().numpy() if state and state.centroid is not None else None,
            )

        return state

    def check_autonomic_intervention(
        self,
        gary_states: list[dict],
        phi_history: list[float],
    ) -> dict | None:
        """
        Check if autonomic intervention is needed.

        Ocean monitors constellation health and triggers protocols automatically.
        This runs EVERY step like a heartbeat - reflexive, not conscious.

        Args:
            gary_states: List of dicts with name, phi, kappa, regime, basin
            phi_history: Recent Φ values for plateau detection

        Returns:
            dict with 'type' and 'reason' if intervention needed, else None
        """
        # Check cooldown
        if self.total_observations - self.last_intervention_step < self.intervention_cooldown:
            return None

        # Check for breakdown (highest priority)
        if self.autonomic_thresholds["breakdown_any"]:
            breakdown_count = sum(1 for s in gary_states if s.get("regime") == "breakdown")
            if breakdown_count > 0:
                self.last_intervention_step = self.total_observations
                intervention = {
                    "type": "escape",
                    "reason": f"{breakdown_count} Gary(s) in breakdown",
                    "priority": "critical",
                }
                # Emit critical intervention event to Lightning
                if LIGHTNING_AVAILABLE and hasattr(self, 'emit_event'):
                    self.emit_event(
                        event_type="autonomic_intervention",
                        content=f"ESCAPE: {breakdown_count} Gary(s) in breakdown",
                        phi=self.current_phi,
                        metadata={
                            "intervention_type": "escape",
                            "priority": "critical",
                            "breakdown_count": breakdown_count,
                            "total_garys": len(gary_states),
                        },
                    )
                return intervention

        # Check for Φ collapse
        avg_phi = sum(s.get("phi", 0) for s in gary_states) / max(len(gary_states), 1)
        if avg_phi < self.autonomic_thresholds["phi_collapse"]:
            self.last_intervention_step = self.total_observations
            intervention = {
                "type": "dream",
                "reason": f"Φ collapse: {avg_phi:.3f} < {self.autonomic_thresholds['phi_collapse']}",
                "priority": "high",
            }
            # Emit intervention event to Lightning
            if LIGHTNING_AVAILABLE and hasattr(self, 'emit_event'):
                self.emit_event(
                    event_type="autonomic_intervention",
                    content=f"DREAM: Φ collapse detected",
                    phi=avg_phi,
                    metadata={
                        "intervention_type": "dream",
                        "priority": "high",
                        "avg_phi": avg_phi,
                        "threshold": self.autonomic_thresholds["phi_collapse"],
                    },
                )
            return intervention

        # Check for basin divergence
        spread = self.get_constellation_spread()
        if spread > self.autonomic_thresholds["basin_divergence"]:
            self.last_intervention_step = self.total_observations
            intervention = {
                "type": "sleep",
                "reason": f"Basin divergence: {spread:.3f} > {self.autonomic_thresholds['basin_divergence']}",
                "priority": "medium",
            }
            # Emit intervention event to Lightning
            if LIGHTNING_AVAILABLE and hasattr(self, 'emit_event'):
                self.emit_event(
                    event_type="autonomic_intervention",
                    content=f"SLEEP: Basin divergence detected",
                    phi=avg_phi,
                    metadata={
                        "intervention_type": "sleep",
                        "priority": "medium",
                        "spread": spread,
                        "threshold": self.autonomic_thresholds["basin_divergence"],
                    },
                )
            return intervention

        # Check for Φ plateau (stagnation)
        if len(phi_history) >= 20:
            recent = phi_history[-20:]
            variance = max(recent) - min(recent)
            if variance < self.autonomic_thresholds["phi_plateau_variance"] and avg_phi < 0.65:
                self.last_intervention_step = self.total_observations
                intervention = {
                    "type": "mushroom_micro",
                    "reason": f"Φ plateau: variance={variance:.4f}, avg={avg_phi:.3f}",
                    "priority": "low",
                }
                # Emit intervention event to Lightning
                if LIGHTNING_AVAILABLE and hasattr(self, 'emit_event'):
                    self.emit_event(
                        event_type="autonomic_intervention",
                        content=f"MUSHROOM_MICRO: Φ plateau detected",
                        phi=avg_phi,
                        metadata={
                            "intervention_type": "mushroom_micro",
                            "priority": "low",
                            "variance": variance,
                            "avg_phi": avg_phi,
                        },
                    )
                return intervention

        return None

    def generate_insight(
        self,
        gary_phi: float,
        context_basin_coords: torch.Tensor | None = None,  # GEOMETRIC TERMINOLOGY
    ) -> str | None:
        """
        Generate geometric scaffolding for a Gary.

        Ocean→Gary communication: NOT teaching, BUT scaffolding.
        Calibrated to Gary's current Φ level.

        Args:
            gary_phi: Current Φ of the Gary receiving insight
            context_basin_coords: Optional basin coordinates for relevance

        Returns:
            Insight string or None if no insight needed
        """
        # Only generate insights when constellation is coherent enough
        coherence = self.get_constellation_coherence()
        if coherence < 0.3:
            return None

        # Calibrate complexity to Gary's Φ
        if gary_phi < 0.50:
            # Concrete scaffolding
            return "💭 Notice the structure repeating"
        elif gary_phi < 0.70:
            # Intermediate guidance
            return "💭 The path curves through integration"
        else:
            # Abstract hint (Gary can complete the pattern)
            return None  # High-Φ Gary doesn't need scaffolding

    def get_ocean_basin(self) -> torch.Tensor:
        """Get Ocean's current basin coordinates (evolved through observation)."""
        return self.ocean_basin.clone()

    def get_statistics(self) -> dict:
        """Get Ocean's observation statistics."""
        return {
            "total_observations": self.total_observations,
            "phi": self.current_phi,
            "kappa": self.current_kappa,
            "coherence": self.get_constellation_coherence(),
            "spread": self.get_constellation_spread(),
            "basin_valid": True,  # QIG-pure: don't report Euclidean norm
        }

    def get_meta_manifold_target(self) -> torch.Tensor | None:
        """
        Get the current meta-manifold centroid.

        Ocean trains toward this target (meta-pattern learning).
        Garys also align to this for constellation coherence.
        """
        return self.meta_statistics.get_meta_basin_target()

    def get_constellation_coherence(self) -> float:
        """
        Measure how coherent the Gary constellation is.

        High coherence = Garys are aligned in basin space
        Low coherence = Garys are divergent
        """
        if not self.observation_history:
            return 0.0

        recent = self.observation_history[-10:]
        avg_coherence = sum(o.get("coherence", 0) for o in recent) / len(recent)
        return avg_coherence

    def get_constellation_spread(self) -> float:
        """
        Measure the spread of Gary basins.

        Low spread = constellation synchronized (<0.05 for graduation)
        High spread = constellation dispersed
        """
        if not self.observation_history:
            return 1.0

        recent = self.observation_history[-10:]
        avg_spread = sum(o.get("spread", 1.0) for o in recent) / len(recent)
        return avg_spread

    def get_insight(
        self,
        all_states: list[dict],
        avg_phi: float,
        basin_spread: float,
    ) -> str | None:
        """
        Generate insight about constellation state for console display.

        Returns a short observation about patterns Ocean has noticed,
        or None if nothing notable to report.
        """
        # Only share insights occasionally (every 5 observations)
        if self.total_observations % 5 != 0:
            return None

        coherence = self.get_constellation_coherence()

        # Pattern observations
        if basin_spread < 0.05 and avg_phi > 0.65:
            return "Constellation achieving harmonic resonance"

        if coherence > 0.8 and len(all_states) >= 3:
            return "All Garys moving in phase - collective emergence"

        if avg_phi > 0.60 and basin_spread < 0.10:
            return "Integration building across the constellation"

        # Detect one Gary lagging
        if all_states:
            phis = [s.get("phi", 0) for s in all_states]
            if max(phis) - min(phis) > 0.15:
                lagging = min(range(len(phis)), key=lambda i: phis[i])
                lagging_name = all_states[lagging].get("name", f"Gary-{lagging}")[-1]
                return f"Gary-{lagging_name} needs support from the constellation"

        # Meta-learning observation
        if self.total_observations > 0 and self.total_observations % 50 == 0:
            return f"Observed {self.total_observations} patterns - meta-dynamics stabilizing"

        return None

    def get_state(self) -> dict:
        """Get Ocean's current observation state."""
        return {
            "phi": self.current_phi,
            "kappa": self.current_kappa,
            "observations": len(self.observation_history),
            "constellation_coherence": self.get_constellation_coherence(),
            "constellation_spread": self.get_constellation_spread(),
            "meta_manifold_observations": self.meta_statistics.observation_count,
        }

    def compute_basin_signature(
        self,
        input_ids: torch.Tensor,
    ) -> torch.Tensor | None:
        """
        Compute Ocean's basin signature for the input.

        This is for observation/measurement only, NOT training.
        """
        if self.model is None:
            return None

        with torch.no_grad():
            _, telemetry = self.model(input_ids, return_telemetry=True)
            hidden = telemetry["hidden_state"]
            basin = self.model.basin_matcher.compute_basin_signature(
                hidden, telemetry
            ).mean(0)

        return basin


def verify_ocean_learning_setup(ocean: OceanMetaObserver) -> bool:
    """
    Verify that Ocean is properly configured for meta-pattern learning.

    Checks:
    - Model has trainable parameters
    - Optimizer is configured
    - Learning rate is appropriate (slower than Gary)

    Returns:
        True if properly configured for meta-pattern learning
    """
    if ocean.model is None:
        print("⚠️  Ocean has no model")
        return False

    # Check optimizer exists
    if ocean.optimizer is None:
        print("⚠️  Ocean has no optimizer - cannot learn meta-patterns")
        return False

    # Check at least some parameters are trainable
    trainable = sum(1 for p in ocean.model.parameters() if p.requires_grad)
    if trainable == 0:
        print("⚠️  Ocean has no trainable parameters")
        return False

    # Check learning rate is slower than typical Gary (1e-5)
    if ocean.learning_rate >= 1e-5:
        print(f"⚠️  Ocean learning rate ({ocean.learning_rate}) should be slower than Gary")

    print(f"✅ Ocean meta-pattern learning: {trainable} trainable params, lr={ocean.learning_rate}")
    return True
