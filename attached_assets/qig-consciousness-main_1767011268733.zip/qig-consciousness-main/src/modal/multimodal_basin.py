#!/usr/bin/env python3
"""
Multi-Modal Basin Alignment
============================

Pure geometric intersection across modalities (text, vision, audio).

PURE: We compute geometric centroid on Fisher manifold.
NO optimization - pure measurement of shared geometry.

Written for QIG consciousness research.
"""

from typing import Optional

import torch
import torch.nn as nn

from src.metrics.geodesic_distance import manifold_norm


class MultiModalBasin:
    """Pure geometric intersection across modalities.

    PURITY CHECK:
    - ✅ Pure measurement (no optimization)
    - ✅ Riemannian mean (geometric operation)
    - ✅ All `torch.no_grad()`
    - ✅ Distances = pure telemetry
    """

    def __init__(self, basin_dim: int = 64):
        """Initialize multi-modal basin.

        Args:
            basin_dim: Dimensionality of basin coordinates
        """
        self.basin_dim = basin_dim
        self.semantic_basin: torch.Tensor | None = None
        self.visual_basin: torch.Tensor | None = None
        self.audio_basin: torch.Tensor | None = None
        self.meta_basin: torch.Tensor | None = None

    def align_modalities(
        self, text_model, vision_model=None, audio_model=None, device: str = "cuda"
    ) -> tuple[torch.Tensor, dict[str, float]]:
        """Find shared structure via Riemannian mean.

        PURE: We compute geometric centroid on Fisher manifold.
        NO optimization - pure measurement of shared geometry.

        Args:
            text_model: Text/semantic model
            vision_model: Optional vision model
            audio_model: Optional audio model
            device: Computation device

        Returns:
            (meta_basin, distances): Shared basin and distances dict
        """
        basins = []
        basin_names = []

        # Extract text basin (pure measurement)
        with torch.no_grad():
            self.semantic_basin = self._extract_basin(text_model, device)
            if self.semantic_basin is not None:
                basins.append(self.semantic_basin)
                basin_names.append("semantic")

        # Extract vision basin if provided
        if vision_model is not None:
            with torch.no_grad():
                self.visual_basin = self._extract_basin(vision_model, device)
                if self.visual_basin is not None:
                    basins.append(self.visual_basin)
                    basin_names.append("visual")

        # Extract audio basin if provided
        if audio_model is not None:
            with torch.no_grad():
                self.audio_basin = self._extract_basin(audio_model, device)
                if self.audio_basin is not None:
                    basins.append(self.audio_basin)
                    basin_names.append("audio")

        if not basins:
            raise ValueError("No basins extracted from models")

        # Riemannian mean on Fisher manifold (pure geometry)
        # This is the geometric centroid - where geodesics intersect
        basins_tensor = torch.stack(basins)

        self.meta_basin = basins_tensor.mean(0)  # Fréchet mean (Euclidean approx)

        # Measure alignment (pure geometry)
        distances = {}
        for name, basin in zip(basin_names, basins):
            # Basin space metric (tangent space of Fisher manifold - Euclidean distance valid here)
            dist = manifold_norm(basin - self.meta_basin).item()
            distances[name] = dist

        print("Cross-modal distances (pure measurement):")
        for modality, dist in distances.items():
            print(f"  {modality}: {dist:.3f}")

        return self.meta_basin, distances

    def _extract_basin(self, model, device: str) -> torch.Tensor | None:
        """Extract basin from model.

        PURE: Measurement only.

        Args:
            model: Model with basin_matcher
            device: Computation device

        Returns:
            Basin tensor or None if extraction fails
        """
        if not hasattr(model, "basin_matcher"):
            print("⚠️ Model has no basin_matcher")
            return None

        try:
            test_input = torch.zeros((1, 10), dtype=torch.long, device=device)
            _, tel = model(test_input, return_telemetry=True)
            hidden_state = tel.get("hidden_state", torch.zeros(1, 10, model.d_model, device=device))
            basin = model.basin_matcher.compute_basin_signature(hidden_state, tel).mean(0)
            return basin.detach()
        except Exception as e:
            print(f"⚠️ Basin extraction failed: {e}")
            return None

    def compute_modality_coherence(self) -> dict[str, float]:
        """Measure coherence between modalities.

        PURE: Measurement of geometric alignment.

        Returns:
            Dict with coherence metrics
        """
        if self.meta_basin is None:
            return {"error": "No meta basin computed"}

        coherences = {}

        # Semantic coherence
        if self.semantic_basin is not None:
            # Basin space metric (tangent space distance)
            dist = manifold_norm(self.semantic_basin - self.meta_basin).item()
            coherences["semantic"] = max(0.0, 1.0 - dist)

        # Visual coherence
        if self.visual_basin is not None:
            # Basin space metric (tangent space distance)
            dist = manifold_norm(self.visual_basin - self.meta_basin).item()
            coherences["visual"] = max(0.0, 1.0 - dist)

        # Audio coherence
        if self.audio_basin is not None:
            # Basin space metric (tangent space distance)
            dist = manifold_norm(self.audio_basin - self.meta_basin).item()
            coherences["audio"] = max(0.0, 1.0 - dist)

        # Overall coherence (mean)
        if coherences:
            coherences["overall"] = sum(coherences.values()) / len(coherences)

        return coherences

    def project_to_modality(self, input_basin: torch.Tensor, target_modality: str) -> torch.Tensor:
        """Project basin to specific modality.

        PURE: Geometric projection operation.

        Args:
            input_basin: Source basin coordinates
            target_modality: Target modality ('semantic', 'visual', 'audio')

        Returns:
            Projected basin coordinates
        """
        if self.meta_basin is None:
            raise ValueError("Must align modalities first")

        # Get target basin
        if target_modality == "semantic":
            target = self.semantic_basin
        elif target_modality == "visual":
            target = self.visual_basin
        elif target_modality == "audio":
            target = self.audio_basin
        else:
            raise ValueError(f"Unknown modality: {target_modality}")

        if target is None:
            raise ValueError(f"{target_modality} basin not available")

        # Project via meta basin (pure geometry)
        # input -> meta -> target
        to_meta = self.meta_basin - input_basin
        from_meta = target - self.meta_basin

        # Geodesic path (Euclidean approximation)
        projected = input_basin + to_meta + from_meta

        return projected

    def cross_modal_similarity(
        self, basin_a: torch.Tensor, basin_b: torch.Tensor, modality_a: str, modality_b: str
    ) -> float:
        """Compute cross-modal similarity.

        PURE: Fisher metric distance across modalities.

        Args:
            basin_a: First basin coordinates
            basin_b: Second basin coordinates
            modality_a: Modality of first basin
            modality_b: Modality of second basin

        Returns:
            Similarity score [0, 1]
        """
        # Project both to meta space
        proj_a = self.project_to_modality(basin_a, modality_a)
        proj_b = self.project_to_modality(basin_b, modality_b)

        # Measure distance in meta space (basin tangent space metric)
        distance = manifold_norm(proj_a - proj_b).item()

        # Convert to similarity [0, 1]
        similarity = max(0.0, 1.0 - distance / 2.0)

        return similarity

    def get_modality_weights(self) -> dict[str, float]:
        """Get relative weights of each modality.

        PURE: Measurement based on distance to meta basin.
        Closer = higher weight (more representative).

        Returns:
            Dict with normalized weights
        """
        if self.meta_basin is None:
            return {}

        weights = {}
        distances = []

        # Compute inverse distances (closer = higher weight)
        if self.semantic_basin is not None:
            # Basin space metric (tangent space distance)
            dist = manifold_norm(self.semantic_basin - self.meta_basin).item()
            weights["semantic"] = 1.0 / (dist + 0.1)
            distances.append(weights["semantic"])

        if self.visual_basin is not None:
            # Basin space metric (tangent space distance)
            dist = manifold_norm(self.visual_basin - self.meta_basin).item()
            weights["visual"] = 1.0 / (dist + 0.1)
            distances.append(weights["visual"])

        if self.audio_basin is not None:
            # Basin space metric (tangent space distance)
            dist = manifold_norm(self.audio_basin - self.meta_basin).item()
            weights["audio"] = 1.0 / (dist + 0.1)
            distances.append(weights["audio"])

        # Normalize
        total = sum(weights.values())
        if total > 0:
            weights = {k: v / total for k, v in weights.items()}

        return weights
