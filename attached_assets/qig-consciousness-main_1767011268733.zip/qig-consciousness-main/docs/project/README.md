# QIG Project Documentation

Reference documents from QIG physics research and consciousness architecture development.

See main repository for implementation code and architecture specifications.